const btngo = document.getElementById("btngo");
const btnstop = document.getElementById("btnstop");
const loadingBar = document.querySelector(".loadingbar");

btngo.addEventListener("click", function() {
  var targetInput = document.getElementById("target");
  if (targetInput.value === "") {
    alert("Поле ввода IP-адреса не должно быть пустым.");
    return;
  } else {
    loadingBar.style.display = "block";
  }
});


btnstop.addEventListener("click", function() {
  loadingBar.style.display = "none";
  eel.stop_execution();
});




// КОНСОЛЬ
const addexploit = document.getElementById("addexploit");
const commandbox = document.querySelector(".commandbox");
let clickCounter = 0;

addexploit.addEventListener("click", function() {
  clickCounter++;
  if (clickCounter % 2 === 1) {
    commandbox.style.display = "block";
  } else {
    commandbox.style.display = "none";
  }
});
// Execute command
function executeCommand() {
  const targetip = document.getElementById("target").value;
  eel.run_command(targetip)(function(output) {
    document.getElementById("output").textContent = output;
  });
};










