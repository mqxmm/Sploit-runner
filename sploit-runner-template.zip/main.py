import os
import eel
import  subprocess
import sys
eel.init("web")
should_continue_execution = True
sys.stdout = open(os.devnull, "w")
@eel.expose
def stop_execution():
    global should_continue_execution
    should_continue_execution = False


@eel.expose
def run_command(targetip):
    output = subprocess.check_output(f"ping -c 1 {targetip}", shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    return output


eel.start("index.html", size=(1280,800), cmdline_args=['--disable-translate'])