const btngo = document.getElementById("btngo");
const btnstop = document.getElementById("btnstop");
const loadingBar = document.querySelector(".loadingbar");

btngo.addEventListener("click", function() {
  var targetInput = document.getElementById("target");
  if (targetInput.value === "") {
    alert("Поле ввода IP-адреса не должно быть пустым.");
    return;
  } else {
    loadingBar.style.display = "block";
    
    // Get the selected value
    const selectedValue = selectedItemId;
    
    // Call the corresponding function based on the selected value
    if (selectedValue === "select1") {
      executePing();
    } else if (selectedValue === "select2") {
      executeSynScan();
    } else if (selectedValue === "select3") {
      executeTCPScan();
    } else if (selectedValue === "select4") {
      executeUDPScan();
    } else if (selectedValue === "select5") {
      executeACKScan();
    }
  }
});


btnstop.addEventListener("click", function() {
  loadingBar.style.display = "none";
  eel.stop_execution();
});


// Function to handle hint mouseover/mouseout
function handleHint(elementId, hintId) {
  const element = document.getElementById(elementId);
  const hint = document.getElementById(hintId);
  
  element.addEventListener("mouseover", function() {
    hint.classList.add("show-element");
  });

  element.addEventListener("mouseout", function() {
    hint.classList.remove("show-element");
  });
}

// Handle hints
handleHint("target", "hint1");
handleHint("ping", "hint3");
handleHint("synscan", "hint4");
handleHint("tcpscan", "hint5");
handleHint("udpscan", "hint6");
handleHint("ackscan", "hint7");
handleHint("arp-spoof", "hint8");

// КОНСОЛЬ
const addexploit = document.getElementById("addexploit");
const commandbox = document.querySelector(".commandbox");
let clickCounter = 0;

addexploit.addEventListener("click", function() {
  clickCounter++;
  if (clickCounter % 2 === 1) {
    commandbox.style.display = "block";
  } else {
    commandbox.style.display = "none";
  }
});
// Execute command
function executeCommand() {
  const command = document.getElementById("command").value;
  eel.run_command(command)(function(output) {
    document.getElementById("output").textContent = output;
  });
};

// PING
function executePing() {
  const targetip = document.getElementById("target").value;
  eel.ping(targetip)(function(output) {
    document.getElementById("output").textContent = output;
  });
};







// SELECTED
let selectedItemId = null;

function toggleSelected(id, selectId) {
  const element = document.getElementById(id);
  const select = document.getElementById(selectId);

  element.addEventListener("click", function() {
    if (selectedItemId !== selectId) {
      // Hide the previously selected item if any
      if (selectedItemId) {
        const prevSelect = document.getElementById(selectedItemId);
        prevSelect.style.display = "none";
      }
      // Show the current item
      select.style.display = "block";
      selectedItemId = selectId;
    } else {
      // Hide the current item if it's already selected
      select.style.display = "none";
      selectedItemId = null;
    }
  });
}

// Toggle selected items
toggleSelected("ping", "select1");
toggleSelected("synscan", "select2");
toggleSelected("tcpscan", "select3");
toggleSelected("udpscan", "select4");
toggleSelected("ackscan", "select5");

// Log target IP
//document.getElementById("ping").addEventListener("click", function() {
  //const targetip = document.getElementById("target").value;
  //console.log(targetip);
//});







